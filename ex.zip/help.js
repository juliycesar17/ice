Handlebars.registerHelper('hhhh', function() {
  console.log(this);
});